from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        """
        Initializes the MongoClient. This helps to access the MongoDB databases and collections.
        """
        # MongoDB connection string using the provided username and password
        self.client = MongoClient(f'mongodb://{username}:{password}@nv-desktop-services.apporto.com:31162/AAC?authSource=admin')
        
        # Database and collection setup
        self.database = self.client['AAC']
        self.collection = self.database['animals']

    # Create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insert = self.collection.insert_one(data)  # insert_one for a single document
            if insert.inserted_id:  # Check if the document was successfully inserted
                return True
            else:
                return False
        else:
            raise Exception("Nothing to insert, because data parameter is empty")
    
    # Read method to implement the R in CRUD.
    def read(self, criteria=None):
        if criteria is not None:
            data = self.collection.find(criteria, {"_id": False})  # Find based on criteria, exclude '_id'
        else:
            data = self.collection.find({}, {"_id": False})  # Find all records, exclude '_id'
        
        return list(data)  # Convert cursor to list and return
    
    # Update method to implement the U in CRUD.
    def update(self, initial, change):
        if initial is not None:
            if self.collection.count_documents(initial, limit=1) != 0:
                update_result = self.collection.update_many(initial, {"$set": change})
                result = update_result.raw_result
            else:
                result = "No document was found"
            return result
        else:
            raise Exception("Nothing to update, because data parameter is empty")
    
    # Delete method to implement the D in CRUD.
    def delete(self, remove):
        if remove is not None:
            if self.collection.count_documents(remove, limit=1) != 0:
                delete_result = self.collection.delete_many(remove)
                result = delete_result.raw_result
            else:
                result = "No document was found"
            return result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
